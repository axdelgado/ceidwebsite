function play(){
     var audio = document.getElementById("audio");
     audio.play();
               }
//http://dev.interactive-creation-works.net/1/1.ogg
